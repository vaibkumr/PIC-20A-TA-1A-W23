package testing;

// A file can only contain one public class,
// and its name must agree with the filename.
public class NotCalledError {}
// "error: class NotCalledError is public,
// should be declared in a file named NotCalledError.java"
