/*
  Nothing about packages is written here,
  so this file uses the "unnamed package".

  To compile and run it...
   - cd to {where you saved things}/PackagesTutorial/compiling
   - run javac UnnamedPackage.java
   - run java UnnamedPackage
*/

class UnnamedPackage {
    public static void main(String[] args) {
        System.out.println("The code in UnnamedPackage.java executed successfully");
    }
}
